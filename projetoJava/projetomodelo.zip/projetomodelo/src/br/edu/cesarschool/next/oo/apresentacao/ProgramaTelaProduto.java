package br.edu.cesarschool.next.oo.apresentacao;

public class ProgramaTelaProduto {

	public static void main(String[] args) {
		TelaProduto tela = new TelaProduto();
		tela.iniciarTela();
	}
}
